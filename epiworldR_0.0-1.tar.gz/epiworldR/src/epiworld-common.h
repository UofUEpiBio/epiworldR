#ifndef EPIWORLD_COMMON_HPP
#define EPIWORLD_COMMON_HPP

#define printf_epiworld fflush(stdout);Rprintf
#include "epiworld.hpp"

#endif
