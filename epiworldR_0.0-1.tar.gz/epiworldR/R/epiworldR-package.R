#' epiworldR
#' @useDynLib epiworldR, .registration = TRUE
"_PACKAGE"

